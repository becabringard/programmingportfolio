import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class mileskilometers extends PApplet {

public void setup() {
  
}

public void draw() {
  background(128);
  //horizontal
  line(0,150,width,150);
  for(int i=0; i<width; i+=20) {
    line(i,146,i,154);
    textSize(8);
    textAlign(CENTER);
    text(i,i,146);
  }
  ellipse(mouseX,150,5,5);
  text("Km:" + convertToKm(mouseX),mouseX,165);
  
  //2nd line
  line(0,200,width,200);
  for(int i=0; i<width; i+=20) {
    line(i,196,i,204);
    textSize(8);
    textAlign(CENTER);
    text(i,i,196);
  }
  ellipse(mouseX,200,5,5);
  text("Mil:" + convertToMil(mouseX),mouseX,215);
  
  
  println("convert 3 kilometers to mils: " + convertToMil(3));
  println("convert 3 miles to Kms: " + convertToKm(3));
  
  //title
  textSize(20);
  textAlign(CENTER);
  text("Miles to Kilometers conversion", width/2, 50);
  
  //description
  textSize(10);
  textAlign(CENTER);
  text("Drag your mouse along the numberlines to figure out \n Miles/Kilometers conversion. The top numberline gives you miles to kilometers, \n and the bottom line gives you kilometers to miles", width/2, 70);
  
  //developer
  text("Beca Bringard | Oct. 2020", width/2, 250);
}

public float convertToMil(float val) {
  val = (val/8.0f)*5;
  return val;
}

public float convertToKm(float val) {
  val = (val/5.0f)*8;
  return val;
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "mileskilometers" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
