import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class etcha_a_sketch extends PApplet {

//Global Variables
int x, y;

public void setup() {
  
  frameRate(10);
  x = 10;
  y = 10;
}

public void draw () {
  fill(0);
  strokeWeight(3);
  if(keyPressed) {
    if(key == 'd' || key == 'D') {
      moveRight(5);
    } else if(key == 'a' || key == 'A') {
      moveLeft(5);
    } else if(key == 'w' || key == 'W') {
      moveUp(5);
    } else if(key == 's' || key == 'S') {
      moveDown(5);
    }
  }
  //drawName();
  //noLoop();
}

public void mouseClicked() {
  saveFrame("line-######.png");
}

public void keyPressed() {
  if(key == CODED) {
    if(keyCode == RIGHT) {
      moveRight(5);
    } else if(keyCode == LEFT) {
      moveLeft(5);
    } else if(keyCode == UP) {
      moveUp(5);
    } else if(keyCode == DOWN) {
      moveDown(5);
    }
  }
}

//Algorithm for your first name
public void drawName() {
  moveDown(100);
  moveUpRight(25);
  moveUpLeft(25);
  moveUpRight(25);
  moveUpLeft(25);
  moveDown(100);
  moveRight(40);
  moveUp(20);
  moveUpRight(12);
  moveDownRight(12);
  moveLeft(24);
  moveDown(10);
  moveDownRight(12);
  moveUpRight(12);
  moveDownLeft(12);
  moveRight(30);
  moveUp(20);
  moveUpRight(10);
  moveDownRight(10);
  moveUpLeft(10);
  moveDownLeft(10);
  moveDown(12);
  moveDownRight(10);
  moveUpRight(10);
  moveDownLeft(10);
  moveRight(20);
  moveUp(20);
  moveUpRight(10);
  moveDownRight(10);
  moveDown(20);
  moveUp(7);
  moveDownLeft(10);
  moveUpLeft(10);
  moveDownRight(10);
  moveUpRight(10);
  moveUp(23);
}

//Method to draw right lines
public void moveRight(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y);
  }
  x=x+rep;
}

//Method to draw left line
public void moveLeft(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y);
  }
  x=x-rep;
}

//Method to draw up lines
public void moveUp(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x, y-i);
  }
  y=y-rep;
}

//Method to draw down
public void moveDown(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x, y+i);
  }
  y=y+rep;
}

//Method to draw down right lines
public void moveDownRight(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y+i);
  }
  x=x+rep;
  y=y+rep;
}

//Method to draw up right lines
public void moveUpRight(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y-i);
  }
  x=x+rep;
  y=y-rep;
}

//Method for up left
public void moveUpLeft(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y-i);
  }
  x=x-rep;
  y=y-rep;
}

//Method for down left
public void moveDownLeft(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y+i);
  }
  x=x-rep;
  y=y+rep;
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "etcha_a_sketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
